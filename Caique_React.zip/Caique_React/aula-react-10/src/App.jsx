import './App.css'
import Header from './components/Header'
import Sidebar from './components/Sidebar'
import InfoCard from './components/InfoCard'
import StatCard from './components/StatCard'
import ProjectCard from './components/ProjectCard'

function App() {
  const stats = [
    { label: 'Total Users', value: '1,200', icon: '👥', color: 'blue' },
    { label: 'Revenue', value: 'R$ 25k', icon: '💰', color: 'green' },
    { label: 'Tasks Done', value: '18', icon: '✓', color: 'orange' },
    { label: 'Support', value: '5', icon: '📞', color: 'red' }
  ]

  const keyTopics = [
    { icon: '📊', title: 'Systems Analysis', description: 'Learn fundamentals', action: 'Get Started' },
    { icon: '💻', title: 'Database Design', description: 'Master data structures', action: 'Get Started' },
    { icon: '🔒', title: 'Security', description: 'Secure your apps', action: 'Get Started' },
    { icon: '⚡', title: 'Performance', description: 'Optimize speed', action: 'Get Started' }
  ]

  const projects = [
    { title: 'Inventory System', description: 'Stock management', tags: ['React', 'Node.js'], image: '📦' },
    { title: 'User Management', description: 'Admin dashboard', tags: ['Vue.js', 'API'], image: '👤' },
    { title: 'E-commerce Site', description: 'Online store', tags: ['Next.js', 'Stripe'], image: '🛒' }
  ]

  return (
    <div className="app">
      <Header />
      <div className="dashboard-container">
        <Sidebar />
        <main className="main-content">
          {/* Statistics Section */}
          <section className="section">
            <h2>Overview</h2>
            <div className="stats-grid">
              {stats.map((stat, index) => (
                <StatCard
                  key={index}
                  label={stat.label}
                  value={stat.value}
                  icon={stat.icon}
                  color={stat.color}
                />
              ))}
            </div>
          </section>

          {/* Key Topics Section */}
          <section className="section">
            <h2>Key Topics</h2>
            <div className="topics-grid">
              {keyTopics.map((topic, index) => (
                <InfoCard
                  key={index}
                  icon={topic.icon}
                  title={topic.title}
                  description={topic.description}
                  action={topic.action}
                />
              ))}
            </div>
          </section>

          {/* Example Projects Section */}
          <section className="section">
            <h2>Example Projects</h2>
            <div className="projects-grid">
              {projects.map((project, index) => (
                <ProjectCard
                  key={index}
                  title={project.title}
                  description={project.description}
                  tags={project.tags}
                  image={project.image}
                />
              ))}
            </div>
          </section>
        </main>
      </div>
    </div>
  )
}

export default App
