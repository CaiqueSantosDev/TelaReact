import './Header.css'

function Header() {
  return (
    <header className="header">
      <div className="header-left">
        <h1>Dashboard</h1>
      </div>
      <div className="header-right">
        <button className="header-btn">Home</button>
        <button className="header-btn">Dashboard</button>
        <button className="header-btn">Insights</button>
        <button className="header-btn login-btn">Login</button>
      </div>
    </header>
  )
}

export default Header
