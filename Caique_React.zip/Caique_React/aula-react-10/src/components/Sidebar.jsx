import './Sidebar.css'

function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="sidebar-logo">📊</div>
        <h3>Menu</h3>
      </div>
      <nav className="sidebar-nav">
        <ul>
          <li className="nav-item"><a href="#"><span>📈</span> Dashboard</a></li>
          <li className="nav-item"><a href="#"><span>📊</span> Analytics</a></li>
          <li className="nav-item"><a href="#"><span>👥</span> Users</a></li>
          <li className="nav-item"><a href="#"><span>⚙️</span> Settings</a></li>
          <li className="nav-item"><a href="#"><span>📋</span> Reports</a></li>
        </ul>
      </nav>
    </aside>
  )
}

export default Sidebar
