import './ProjectCard.css'

function ProjectCard({ title, description, tags, image }) {
  return (
    <div className="project-card">
      <div className="project-image">
        {image}
      </div>
      <h4>{title}</h4>
      <p>{description}</p>
      <div className="project-tags">
        {tags.map((tag, index) => (
          <span key={index} className="tag">{tag}</span>
        ))}
      </div>
      <button className="project-btn">View Details</button>
    </div>
  )
}

export default ProjectCard
