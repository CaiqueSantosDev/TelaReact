import './InfoCard.css'

function InfoCard({ icon, title, description, action }) {
  return (
    <div className="info-card">
      <div className="info-card-icon">{icon}</div>
      <h3>{title}</h3>
      <p>{description}</p>
      {action && <button className="info-card-btn">{action}</button>}
    </div>
  )
}

export default InfoCard
