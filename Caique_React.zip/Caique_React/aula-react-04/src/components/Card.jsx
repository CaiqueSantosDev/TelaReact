import './Card.css'

function Card({ image, title, description, buttonText, buttonColor }) {
  return (
    <div className="card-container">
      <div className={`card-image ${buttonColor}`}>
        <img src={image} alt={title} />
      </div>
      <h3>{title}</h3>
      <p>{description}</p>
      <button className={`card-button ${buttonColor}`}>{buttonText}</button>
    </div>
  )
}

export default Card
