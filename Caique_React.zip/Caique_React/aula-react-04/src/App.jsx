import './App.css'
import Card from './components/Card'
import img1 from './images/6806.6YzqdACyWJkC.jpg'
import img2 from './images/10818.Flkl8yHJJF2u.jpg'
import img3 from './images/41670.UxypdZ_C2H_b.jpg'

function App() {
  const cards = [
    {
      id: 1,
      image: img1,
      title: 'CHARCHAR',
      description: 'O REI DA IA.',
      buttonText: 'Button',
      buttonColor: 'blue'
    },
    {
      id: 2,
      image: img2,
      title: 'warllão',
      description: 'o rei do web developing.',
      buttonText: 'Button',
      buttonColor: 'green'
    },
    {
      id: 3,
      image: img3,
      title: 'Edsuzão',
      description: 'O mago da pedagogia.',
      buttonText: 'Button',
      buttonColor: 'orange'
    }
  ]

  return (
    <div className="app-container">
      <h1>TOP PROFESSORES IFPI</h1>
      <div className="cards-container">
        {cards.map(card => (
          <Card
            key={card.id}
            image={card.image}
            title={card.title}
            description={card.description}
            buttonText={card.buttonText}
            buttonColor={card.buttonColor}
          />
        ))}
      </div>
    </div>
  )
}

export default App
