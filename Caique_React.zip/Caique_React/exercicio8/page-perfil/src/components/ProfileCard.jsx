export default function ProfileCard() {
  return (
    <div className="profile-card">
      <img
        src="https://i.pravatar.cc/150"
        alt="Foto do usuário"
        className="avatar"
      />

      <h2>John Doe</h2>

      <p>Email: john@example.com</p>
      <p>Location: São Paulo, Brazil</p>
    </div>
  );
}
