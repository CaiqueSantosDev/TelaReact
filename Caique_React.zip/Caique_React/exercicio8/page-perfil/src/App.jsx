import ProfileCard from "./components/ProfileCard";

function App() {
  return <ProfileCard />;
}

export default App;
