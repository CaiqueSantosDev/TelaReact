export default function Sidebar() {
  return (
    <aside className="sidebar">
      <h3>Header</h3>
      <ul>
        <li>⌂ Home</li>
        <li>📊 Reports</li>
        <li>⚙️ Settings</li>
      </ul>
    </aside>
  );
}
