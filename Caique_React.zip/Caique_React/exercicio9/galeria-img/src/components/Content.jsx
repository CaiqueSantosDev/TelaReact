export default function Content() {
  return (
    <div className="content-wrapper">
      <div className="gallery">
        <div className="card-img" style={{ backgroundColor: '#ff9900' }}>
          <h2>Photo</h2>
        </div>
        <div className="card-img" style={{ backgroundColor: '#ff9900' }}>
          <h2>Photo</h2>
        </div>
        <div className="card-img" style={{ backgroundColor: '#ff9900' }}>
          <h2>Photo</h2>
        </div>
        <div className="card-img" style={{ backgroundColor: '#ff9900' }}>
          <h2>Photo</h2>
        </div>
        <div className="card-img" style={{ backgroundColor: '#ff9900' }}>
          <h2>Photo</h2>
        </div>
        <div className="card-img" style={{ backgroundColor: '#ff9900' }}>
          <h2>Photo</h2>
        </div>
      </div>
      <div className="stats">
        <div className="stat-card">
          <h4>Users</h4>
          <p>1200</p>
        </div>
        <div className="stat-card">
          <h4>Sales</h4>
          <p>R$ 25k</p>
        </div>
        <div className="stat-card">
          <h4>Tasks</h4>
          <p>18</p>
        </div>
      </div>
    </div>
  );
}
