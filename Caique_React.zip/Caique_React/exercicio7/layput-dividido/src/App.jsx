import TwoColumnLayout from "./components/TwoColumnLayout";

function App() {
  return <TwoColumnLayout />;
}

export default App;
