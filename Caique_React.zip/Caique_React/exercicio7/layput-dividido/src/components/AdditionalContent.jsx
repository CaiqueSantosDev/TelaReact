export default function AdditionalContent() {
  return (
    <section className="content">
      <h2>Additional Content</h2>
    </section>
  );
}
