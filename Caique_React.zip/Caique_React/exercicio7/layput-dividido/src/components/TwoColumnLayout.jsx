import UserInfo from "./UserInfo";
import AdditionalContent from "./AdditionalContent";

export default function TwoColumnLayout() {
  return (
    <div className="container">
      <UserInfo />
      <AdditionalContent />
    </div>
  );
}
