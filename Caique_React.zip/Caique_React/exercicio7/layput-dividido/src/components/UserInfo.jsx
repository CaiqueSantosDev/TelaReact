export default function UserInfo() {
  return (
    <section className="user">
      <h2>User Info</h2>
    </section>
  );
}
