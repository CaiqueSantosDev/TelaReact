function Main() {
  return (
    <main className="main">
      <h1>Main Content</h1>
    </main>
  );
}

export default Main;
