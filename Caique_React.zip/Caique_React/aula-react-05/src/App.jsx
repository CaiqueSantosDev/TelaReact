import './App.css'
import ProductList from './components/ProductList'
import img1 from './images/download.jpeg'
import img2 from './images/download (1).jpeg'
import img3 from './images/download (2).jpeg'

function App() {
  const products = [
    {
      image: img1,
      name: 'Mouse',
      price: 'R$ 99,90',
      color: 'purple'
    },
    {
      image: img2,
      name: 'Teclado',
      price: 'R$ 99,90',
      color: 'blue'
    },
    {
      image: img3,
      name: 'Monitor',
      price: 'R$ 99,90',
      color: 'indigo'
    }
  ]

  return (
    <div className="app-container">
      <h1>Exercício 5 - Lista de Produtos</h1>
      <div className="list-container">
        <h2>5. Product List</h2>
        <ProductList products={products} />
      </div>
    </div>
  )
}

export default App
