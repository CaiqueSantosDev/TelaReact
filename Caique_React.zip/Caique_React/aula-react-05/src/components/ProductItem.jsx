import './ProductItem.css'

function ProductItem({ image, name, price, onBuy }) {
  return (
    <div className="product-item">
      <div className="product-image">
        <img src={image} alt={name} />
      </div>
      <div className="product-info">
        <h3>{name}</h3>
        <p className="price">{price}</p>
      </div>
      <button className="buy-button" onClick={onBuy}>Buy</button>
    </div>
  )
}

export default ProductItem
