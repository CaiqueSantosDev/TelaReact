import './ProductList.css'
import ProductItem from './ProductItem'

function ProductList({ products }) {
  const handleBuy = (productName) => {
    alert(`Produto "${productName}" adicionado ao carrinho!`)
  }

  return (
    <div className="product-list-container">
      <div className="product-list">
        {products.map((product, index) => (
          <ProductItem
            key={index}
            image={product.image}
            name={product.name}
            price={product.price}
            onBuy={() => handleBuy(product.name)}
          />
        ))}
      </div>
    </div>
  )
}

export default ProductList
