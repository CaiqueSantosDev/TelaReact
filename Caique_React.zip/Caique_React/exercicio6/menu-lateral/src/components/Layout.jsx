import Sidebar from "./Sidebar";
import Content from "./Content";

export default function Layout() {
  return (
    <div className="layout">
      <Sidebar />
      <Content />
    </div>
  );
}
