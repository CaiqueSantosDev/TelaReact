export default function Sidebar() {
  return (
    <aside className="sidebar">
      <h3>Sidebar</h3>
      <ul>
        <li>Dashboard</li>
        <li>Profile</li>
        <li>Messages</li>
        <li>Settings</li>
      </ul>
    </aside>
  );
}
