export default function Content() {
  return (
    <main className="content">
      <h2>Main Content</h2>
    </main>
  );
}
