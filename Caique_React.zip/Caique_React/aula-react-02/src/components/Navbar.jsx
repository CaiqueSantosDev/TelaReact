import './Navbar.css'

function Navbar({ onNavigate }) {
  return (
    <nav className="navbar">
      <span className="logo" onClick={() => onNavigate('home')}>Logo</span>
      <ul className="nav-menu">
        <li><button onClick={() => onNavigate('home')}>Home</button></li>
        <li><button onClick={() => onNavigate('about')}>About</button></li>
        <li><button onClick={() => onNavigate('service')}>Service</button></li>
        <li><button onClick={() => onNavigate('contact')}>Contact</button></li>
      </ul>
    </nav>
  )
}

export default Navbar
