import { useState } from 'react'
import './App.css'
import Navbar from './components/Navbar'

function App() {
  const [page, setPage] = useState('home')

  return (
    <>
      <Navbar onNavigate={setPage} />
      <div className="content">
        {page === 'home' && <h1>Home</h1>}
        {page === 'about' && <h1>About</h1>}
        {page === 'service' && <h1>Service</h1>}
        {page === 'contact' && <h1>Contact</h1>}
      </div>
    </>
  )
}

export default App
